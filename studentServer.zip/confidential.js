exports.pass = 'samsung2000'
exports.connString = 'Data Source=DESKTOP-PAP9J4B\SQLEXPRESS;Initial Catalog=persondb;Integrated Security=True;Connect Timeout=30;Encrypt=False;TrustServerCertificate=False;ApplicationIntent=ReadWrite;MultiSubnetFailover=False'
exports.server = 'localhost'//'DESKTOP-PAP9J4B\\SQLEXPRESS'